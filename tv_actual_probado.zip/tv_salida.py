from __future__ import annotations

from datetime import datetime

from sqlalchemy import Boolean, DateTime, ForeignKey, Integer, String
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.core.database import Base


class TvSalida(Base):
    """Estado único de la salida gráfica que consume vMix.

    El token forma parte de la URL secreta. La salida no requiere sesión porque
    vMix debe poder abrirla directamente, pero sólo TV/MASTER pueden ver o
    regenerar ese token desde el panel autenticado.
    """

    __tablename__ = "tv_salidas"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)

    token: Mapped[str] = mapped_column(
        String(80),
        nullable=False,
        unique=True,
        index=True,
    )

    escena: Mapped[str] = mapped_column(
        String(30),
        nullable=False,
        default="oculto",
    )

    sorteo_id: Mapped[int | None] = mapped_column(
        ForeignKey("sorteos.id", ondelete="SET NULL"),
        nullable=True,
        index=True,
    )

    detalle_id: Mapped[int | None] = mapped_column(
        ForeignKey("sorteo_detalles.id", ondelete="SET NULL"),
        nullable=True,
        index=True,
    )

    tabla_pagina: Mapped[int] = mapped_column(
        Integer,
        nullable=False,
        default=1,
    )

    tabla_auto: Mapped[bool] = mapped_column(
        Boolean,
        nullable=False,
        default=True,
    )

    ticker_cantidad: Mapped[int] = mapped_column(
        Integer,
        nullable=False,
        default=6,
    )

    actualizado_en: Mapped[datetime] = mapped_column(
        DateTime,
        nullable=False,
        default=datetime.utcnow,
        onupdate=datetime.utcnow,
    )

    sorteo = relationship("Sorteo")
    detalle = relationship("SorteoDetalle")
